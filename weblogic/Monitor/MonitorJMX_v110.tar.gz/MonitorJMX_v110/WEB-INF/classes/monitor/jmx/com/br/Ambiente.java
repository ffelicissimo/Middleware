package monitor.jmx.com.br;

import java.io.File;
import java.util.ArrayList;

public class Ambiente {
	String environmentAlias;
	String user;
	String password;
	String host;
	String port;
	public static String msg;
	public static String msg2 = null;
	public static String CONFIG_FILE = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//WEB-INF//classes//conf.properties";

	public Ambiente() {
	}

	public String getEnvironmentAlias() {
		return environmentAlias;
	}

	public void setEnvironmentAlias(String paramString) {
		environmentAlias = paramString;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String paramString) {
		user = paramString;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String paramString) {
		password = paramString;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String paramString) {
		host = paramString;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String paramString) {
		port = paramString;
	}

	public void adicionarAmbiente(Ambiente paramAmbiente) {

		try {
			java.io.BufferedWriter localBufferedWriter = new java.io.BufferedWriter(
					new java.io.FileWriter(CONFIG_FILE, true));
			localBufferedWriter.flush();
			localBufferedWriter.append(paramAmbiente.getEnvironmentAlias() + "=" + paramAmbiente.getUser() + ";"
					+ paramAmbiente.getPassword() + ";" + paramAmbiente.getHost() + ";" + paramAmbiente.getPort()
					+ ";t3" + System.getProperty("line.separator"));
			localBufferedWriter.close();
			msg = paramAmbiente.getEnvironmentAlias();
		} catch (java.io.IOException localIOException) {
			System.out.println(
					"Erro na operacao com o arquivo. Verifique se o arquivo existe, se ha permissoes de escrita ou ha espaco no FS.");
			msg = "Erro na operacao com o arquivo. Verifique se o arquivo existe, se ha permissoes de escrita ou ha espaco no FS.";
		}
	}

	public ArrayList<String> listarAmbientes() {
		// str = "d://arquivo.txt";
		java.io.BufferedReader localBufferedReader = null;
		String linha;
		// String tela = System.getProperty("line.separator");
		ArrayList<String> linhasDaTela = new ArrayList<String>();
		try {
			File arq = new File(CONFIG_FILE);
			localBufferedReader = new java.io.BufferedReader(new java.io.FileReader(arq));
			linha = localBufferedReader.readLine();
			while (linha != null) {
				if (linha.contains("defaultEnv") == false && linha.contains("#") == false
						&& linha.contains("webmonitor") == true) {
					linha = "<tr><td>" + linha;
					linha = linha.replace("=", "</td><td align='center'>");
					linha = linha.replace(";think@09;", "</td><td align=center>");
					linha = linha.replace(";t3", "</td></tr>");
					linhasDaTela.add(linha);
				}

				linha = localBufferedReader.readLine();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return linhasDaTela;
	}
}

