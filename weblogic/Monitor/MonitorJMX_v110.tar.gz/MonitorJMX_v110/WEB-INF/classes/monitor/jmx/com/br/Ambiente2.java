package monitor.jmx.com.br;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Writer;

public class Ambiente2 {

	String environmentAlias;
	String user;
	String password;
	String host;
	String port;
	int indexPage;
	String indexFile;

	public String getIndexFile() {
		return indexFile;
	}

	public void setIndexFile(String indexFile) {
		this.indexFile = indexFile;
	}

	public int getIndexPage() {
		return indexPage;
	}

	public void setIndexPage(int indexPage) {
		this.indexPage = indexPage;
	}

	public String getEnvironmentAlias() {
		return environmentAlias;
	}

	public void setEnvironmentAlias(String environmentAlias) {
		this.environmentAlias = environmentAlias;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public static String msg;

	@SuppressWarnings("static-access")
	public void adicionarAmbiente(Ambiente2 a) {

		String arquivo = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//WEB-INF//classes//conf.properties";
		Writer output;
		String line;
		boolean continuar = true;
		String linhaIndex = "<br><td><a target='_blank' href='./wls.jsp?env='" + a.getEnvironmentAlias() + "'>"
				+ a.getEnvironmentAlias() + "</a></td>" + System.getProperty("line.separator");

		try {
			output = new BufferedWriter(new FileWriter(arquivo, true));
			output.flush();
			output.append(a.getEnvironmentAlias() + "=" + a.getUser() + ";" + a.getPassword() + ";" + a.getHost() + ";"
					+ a.getPort() + ";t3" + System.getProperty("line.separator"));
			output.close();
			msg = a.getEnvironmentAlias();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			msg = "Erro na operacao com o arquivo. Verifique se o arquivo existe, se ha permissoes de escrita ou ha espaco no FS.";
		}

		switch (indexPage) {
		case 1:
			indexFile = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//index_NGIN.html";
			try {
				InputStream fileInputStream = new FileInputStream(indexFile);
				InputStreamReader inputReader = new InputStreamReader(fileInputStream);
				BufferedReader bufferedReader = new BufferedReader(inputReader);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case 2:
			indexFile = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//index_Movel2.html";
			try {
				InputStream fileInputStream = new FileInputStream(indexFile);
				InputStreamReader inputReader = new InputStreamReader(fileInputStream);
				BufferedReader bufferedReader = new BufferedReader(inputReader);
				output = new BufferedWriter(new FileWriter(indexFile + 2, true));

				while ((line = bufferedReader.readLine()) != null) {

					output.flush();
					output.write(line + System.getProperty("line.separator"));
					if (line.contains("wls") && continuar == true) {
						output.append(linhaIndex);
						continuar = false;
					} else {
						// do nothing
					}

				}

				bufferedReader.close();
				inputReader.close();
				fileInputStream.close();
				output.close();

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case 3:
			indexFile = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//index_Fixa.html";
			try {
				InputStream fileInputStream = new FileInputStream(indexFile);
				InputStreamReader inputReader = new InputStreamReader(fileInputStream);
				BufferedReader bufferedReader = new BufferedReader(inputReader);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;

		case 4:
			indexFile = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//index_SOA.html";
			try {
				InputStream fileInputStream = new FileInputStream(indexFile);
				InputStreamReader inputReader = new InputStreamReader(fileInputStream);
				BufferedReader bufferedReader = new BufferedReader(inputReader);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		default:
		}

	}

}

