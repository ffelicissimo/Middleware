package monitor.jmx.com.br;

import java.util.ArrayList;

import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public class CollectDomainInstancesData {

	public int GetDomainInstancesCount(MBeanServerConnection connection) {

		ObjectName service;

		int length = 0;

		try {
			service = new ObjectName(
					"com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
		} catch (MalformedObjectNameException e) {
			throw new AssertionError(e.getMessage());
		}

		try {

			ObjectName domainConfig = (ObjectName) connection.getAttribute(service, "DomainRuntime");

			ObjectName[] servers = (ObjectName[]) connection.getAttribute(domainConfig, "ServerLifeCycleRuntimes");

			length = (int) servers.length;

		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return length;
	}

	public ArrayList<String> GetDomainShutdownInstancesCount(MBeanServerConnection connection) {

		ObjectName service;

		ArrayList<String> allServersStringList = new ArrayList<String>();
		ArrayList<String> serversShutdown = new ArrayList<String>();
		ArrayList<String> serversRunning = new ArrayList<String>();

		try {
			service = new ObjectName(
					"com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean");
		} catch (MalformedObjectNameException e) {
			throw new AssertionError(e.getMessage());
		}

		try {

			ObjectName domainConfig = (ObjectName) connection.getAttribute(service, "DomainRuntime");

			ObjectName[] allServers = (ObjectName[]) connection.getAttribute(domainConfig, "ServerLifeCycleRuntimes");

			ObjectName[] serverRT = (ObjectName[]) connection.getAttribute(service, "ServerRuntimes");

			for (ObjectName a : allServers) {
				String aName = (String) connection.getAttribute(a, "Name");
				allServersStringList.add(aName);

			}

			for (ObjectName a : serverRT) {
				String aName = (String) connection.getAttribute(a, "Name");
				serversRunning.add(aName);

			}

			for (String a : allServersStringList) {
				System.out.println(a);
				if (serversRunning.contains(a)) {

				} else {

					serversShutdown.add(a);
				}

			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return serversShutdown;
	}
}
