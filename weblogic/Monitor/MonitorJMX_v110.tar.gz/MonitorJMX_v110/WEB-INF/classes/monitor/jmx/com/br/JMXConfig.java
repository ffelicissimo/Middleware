package monitor.jmx.com.br;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class JMXConfig {
	
	public void adicionarAmbiente(String environmentAlias, String user, String password,String host, String port)  {
	Writer output;
	String arquivo = "//opt//web//wl//wls1036//domains//MonitorJMX_Middleware//MonitorJMX_v110//WEB-INF//classes//conf.properties";
	
	try {
		output = new BufferedWriter(new FileWriter(arquivo, true)); 
		output.append(environmentAlias + "=" + user + ";" + password + ";" + host + ";" + port + ";t3" );
		output.close();
	} catch (IOException e) {
		System.out.println("Erro na operacao com o arquivo. Verifique se o arquivo existe, se ha permissoes de escrita ou ha espaco no FS.");
	}
	
	}

}
