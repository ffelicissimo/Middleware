<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
</head>
<body>
<table style="text-align: left; width: 1170px;" border="0"
 cellpadding="0" cellspacing="0">
  <tbody>
    <tr>
      <td
 style="vertical-align: middle; text-align: center; height: 60px; width: 60px;"></td>
      <td
 style="vertical-align: middle; text-align: center; height: 60px;"></td>
    </tr>
    <tr>
      <td style="vertical-align: middle; text-align: center;"></td>
      <td style="text-align: center; vertical-align: middle;"><big
 style="color: rgb(51, 51, 255);"><span
 style="font-weight: bold; font-family: Helvetica,Arial,sans-serif;">&nbsp;<img
 style="width: 45px; height: 45px;" alt=""
 src="../../imagens/upload_icon2.jpg">&nbsp; <big><big>FERRAMENTA
DE UPLOAD</big></big></span></big></td>
    </tr>
    <tr>
      <td align="center" valign="middle"></td>
      <td style="font-family: Helvetica,Arial,sans-serif; 
      "align="center" valign="middle">
<?php 

// Where the file is going to be placed 

    if ($_POST['radio'] == 'internal' ) { 

         $target_path = "/opt/web/htdocs/supmid_home/interno/upload/files/";
         $context = "upload/files/";
	 $url = "http://suportemiddleware.vivo.com.br/" . $context . basename( $_FILES['uploadedfile']['name']);
	 $url2 = "http://10.238.2.89/" . $context . basename( $_FILES['uploadedfile']['name']);

    } elseif ($_POST['radio'] == 'public' ) { 

         $target_path = "/opt/web/htdocs/supmid_home/upload-public/";
         $context = "upload-public/";
	 $url = "http://suportemiddleware.vivo.com.br/" . $context . basename( $_FILES['uploadedfile']['name']);
	 $url2 = "http://10.238.2.89/" . $context . basename( $_FILES['uploadedfile']['name']);

    }
    else {
         echo "Error: You Don't Select Internal ou Public Area" . "<br>";
    }

/* Add the original filename to our target path. Result is "uploads/filename.extension" */
$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 
if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {

echo "<table style=\"text-align: left; width: 550px;\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
echo "    <tr style=\"font-family: Helvetica,Arial,sans-serif;\">";
echo "      <td  align=\"center\" valign=\"middle\">";
echo "		<br><br>". "The file ". "<b>" . basename( $_FILES['uploadedfile']['name']). "</b>" . " has been uploaded" . "<br><br>";
echo "      </td>";
echo "    </tr>";
echo "    <tr style=\"font-family: Helvetica,Arial,sans-serif;\" align=\"left\">";
echo "      <td valign=\"middle\">";
echo "	    <b>" . "Download your file using the url:" . "</b><br><br>";
echo "      </td>";
echo "    </tr>";
echo "    <tr style=\"font-family: Helvetica,Arial,sans-serif;\" align=\"left\">";
echo "      <td valign=\"middle\">";
echo "         <a target=\"_blank\" href=\"$url\">$url</a>";
echo "      </td>";
echo "    </tr>";
echo "    <tr style=\"font-family: Helvetica,Arial,sans-serif;\">";
echo "      <td  style=\"vertical-align: middle; text-align: center;\">";
echo "		or" . "<br>";
echo "      </td>";
echo "    </tr>";
echo "    <tr style=\"font-family: Helvetica,Arial,sans-serif;\" align=\"left\">";
echo "      <td valign=\"middle\">";
echo "         <a target=\"_blank\" href=\"$url2\">$url2</a>";
echo "      </td>";
echo "    </tr>";
echo "</table>";
} else{
        echo "<br>";
	echo "There was an error uploading the file, please try again!" . "<br>";
	echo "<br>";
	echo "Or maybe your file exceeded 100MB" . "<br>";
	echo "<br>";
    }
?>
<br>
      <input onclick="history.back();" value="Back" type="button">
      </td>
    </tr>
    <tr>
      <td
 style="vertical-align: middle; text-align: center; height: 30px; width: 30px;"></td>
      <td style="vertical-align: middle; text-align: center;"></td>
    </tr>
  </tbody>
</table>
</body>
</html>
