                                <!-- Begin
                                var Today=new Date();
                                var ThisDay=Today.getDay();
                                var ThisDate=Today.getDate();
                                var ThisMonth=Today.getMonth()+1;
                                var ThisYear=Today.getFullYear();  //included if you wish to insert the year
                                function DayTxt (DayNumber) {
                                var Day=new Array();
                                Day[0]="Sunday";
                                Day[1]="Monday";
                                Day[2]="Tuesday";
                                Day[3]="Wednesday";
                                Day[4]="Thursday";
                                Day[5]="Friday";
                                Day[6]="Saturday";
                                return Day[DayNumber];
                                }
                                var DayName=DayTxt(ThisDay);
                                function MonthTxt (MonthNumber) {
                                var Month=new Array();
                                Month[1]="January";
                                Month[2]="February";
                                Month[3]="March";
                                Month[4]="April";
                                Month[5]="May";
                                Month[6]="June";
                                Month[7]="July";
                                Month[8]="August";
                                Month[9]="September";
                                Month[10]="October";
                                Month[11]="November";
                                Month[12]="December";
                                return Month[MonthNumber];
                                }
                                var MonthName=MonthTxt(ThisMonth);
                                var d = new Date();
                                var h = d.getHours();
